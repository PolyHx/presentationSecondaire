package io.polyhx;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.math.Vector2;
import io.polyhx.engine.entities.AnimatedSpriteEntity;
import io.polyhx.engine.entities.Label;
import io.polyhx.engine.entities.SpriteEntity;
import io.polyhx.engine.utils.Clock;
import io.polyhx.engine.utils.Constants;
import io.polyhx.engine.utils.Mouse;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Vector;

public class Game {


    public Game() {

    }

    public void act(float delta) {

    }

    public void draw(Batch batch) {

    }
}